# -*- coding: utf-8 -*-
"""
Created on Sat Nov 30 21:20:05 2024

@author: balak
"""

import cupy as cp
import sys
ni=1 
nj=96 
yfac=1.15 # stretching
viscos=1/5200
dy=0.1
ymax=2
xmax=0.6
yc=cp.zeros(nj+1)
yc[0]=0.
for j in range(1,int(nj/2)+1):
    yc[j]=yc[j-1]+dy
    dy=yfac*dy


ymax_scale=yc[int(nj/2)]

# cell faces
for j in range(1,int(nj/2)+1):
   yc[j]=yc[j]/ymax_scale
   yc[nj-j+1]=ymax-yc[j-1]

yc[int(nj/2)]=1

print('y+',0.5*yc[1]/viscos)
# make it 2D
y2d=cp.repeat(yc[None,:], repeats=ni+1, axis=0)

y2d=cp.append(y2d,nj)
cp.savetxt('y2d.dat', y2d)

# x grid
xc = cp.linspace(0, xmax, ni+1)
# make it 2D
x2d=cp.repeat(xc[:,None], repeats=nj+1, axis=1)
x2d_org=x2d
x2d=cp.append(x2d,ni)
cp.savetxt('x2d.dat', x2d)

# check it
datay= cp.loadtxt("y2d.dat")
y=datay[0:-1]
nj=int(datay[-1])

y2=cp.zeros((ni+1,nj+1))
y2=cp.reshape(y,(ni+1,nj+1))

datax= cp.loadtxt("x2d.dat")
x=datax[0:-1]
ni=int(datax[-1])

x2=cp.zeros((ni+1,nj+1))
x2=cp.reshape(x,(ni+1,nj+1))

